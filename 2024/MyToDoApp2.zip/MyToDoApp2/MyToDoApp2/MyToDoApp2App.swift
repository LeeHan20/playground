//
//  MyToDoApp2App.swift
//  MyToDoApp2
//
//  Created by 이한 on 5/3/25.
//

import SwiftUI

@main
struct MyToDoApp2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
