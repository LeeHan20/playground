import SwiftUI

// MARK: - Model

enum TaskState: String, CaseIterable, Identifiable {
    case notAtWork = "Not At Work"
    case atWork    = "At Work"
    case done      = "Done"

    var id: String { self.rawValue }
    var assetName: String {
        switch self {
        case .notAtWork: return "task_notAtWork"
        case .atWork:    return "task_atWork"
        case .done:      return "task_done"
        }
    }
}

struct Task: Identifiable, Equatable {
    let id: UUID
    var title: String
    var startDate: Date?
    var endDate: Date?
    var location: String?
    var note: String?
    var state: TaskState

    init(
        id: UUID = UUID(),
        title: String,
        startDate: Date? = nil,
        endDate: Date? = nil,
        location: String? = nil,
        note: String? = nil,
        state: TaskState = .notAtWork
    ) {
        self.id = id
        self.title = title
        self.startDate = startDate
        self.endDate = endDate
        self.location = location
        self.note = note
        self.state = state
    }
}

// MARK: - Task Utility Extensions

extension Task {
    /// 진행 비율 (0.0 ~ 1.0)
    func progress(at date: Date = Date()) -> Double {
        guard let start = startDate,
              let end = endDate,
              end > start else {
            return 0
        }
        let elapsed = date.timeIntervalSince(start)
        let duration = end.timeIntervalSince(start)
        return min(max(elapsed / duration, 0), 1)
    }
    /// 자동 상태 업데이트 (단, state == .done인 경우 유지)
    mutating func autoUpdateState(at date: Date = Date()) {
        guard state != .done,
              let start = startDate,
              let end = endDate else {
            return
        }
        if date < start {
            state = .notAtWork
        } else if date <= end {
            state = .atWork
        } else {
            // leave .atWork until user taps done
        }
    }
}

// MARK: - ViewModel

class TaskViewModel: ObservableObject {
    @Published var tasks: [Task] = []

    func addTask(
        title: String,
        startDate: Date?,
        endDate: Date?,
        location: String?,
        note: String?
    ) {
        let newTask = Task(
            title: title,
            startDate: startDate,
            endDate: endDate,
            location: location,
            note: note
        )
        tasks.append(newTask)
    }

    func deleteTask(_ task: Task) {
        tasks.removeAll { $0.id == task.id }
    }

    func updateTask(_ task: Task) {
        if let idx = tasks.firstIndex(where: { $0.id == task.id }) {
            tasks[idx] = task
        }
    }
}

// MARK: - PieShape for circular reveal

struct PieShape: Shape {
    var progress: Double
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let center = CGPoint(x: rect.midX, y: rect.midY)
        let radius = min(rect.width, rect.height) / 2
        path.move(to: center)
        path.addArc(
            center: center,
            radius: radius,
            startAngle: Angle(degrees: -90),
            endAngle: Angle(degrees: -90 + progress * 360),
            clockwise: false
        )
        path.closeSubpath()
        return path
    }
}

// MARK: - ContentView (List)

struct ContentView: View {
    @StateObject private var viewModel = TaskViewModel()
    @State private var showAdd = false
    @State private var now = Date()
    private let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    var body: some View {
        NavigationView {
            List {
                ForEach(viewModel.tasks) { task in
                    HStack {
                        let prog: Double = {
                            switch task.state {
                            case .done:   return 1
                            case .atWork: return task.progress(at: now)
                            case .notAtWork: return 0
                            }
                        }()
                        Image(task.state.assetName)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 40, height: 40)
                            .clipShape(Circle())
                            .overlay(Circle().stroke(Color.primary, lineWidth: 1))
                            .mask(PieShape(progress: prog))

                        NavigationLink(destination: TaskDetailView(viewModel: viewModel, task: task)) {
                            VStack(alignment: .leading) {
                                Text(task.title)
                                    .font(.headline)
                                if let loc = task.location, !loc.isEmpty {
                                    Text(loc)
                                        .font(.subheadline)
                                        .foregroundColor(.secondary)
                                }
                            }
                        }
                    }
                    .padding(.vertical, 4)
                }
                .onDelete { idxs in
                    idxs.map { viewModel.tasks[$0] }.forEach(viewModel.deleteTask)
                }
            }
            .listStyle(InsetGroupedListStyle())
            .navigationTitle("MY ToDo Lists")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { showAdd = true } label: { Image(systemName: "plus") }
                }
            }
            .sheet(isPresented: $showAdd) {
                AddTaskView(viewModel: viewModel)
            }
            .onReceive(timer) { now = $0 }
        }
    }
}

// MARK: - AddTaskView

struct AddTaskView: View {
    @Environment(\.presentationMode) var pm
    @ObservedObject var viewModel: TaskViewModel

    @State private var title = ""
    @State private var start = Date()
    @State private var end = Date()
    @State private var location = ""
    @State private var note = ""

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("What To Do?")) {
                    TextField("Title", text: $title)
                }
                Section(header: Text("Start Date & Time")) {
                    DatePicker("Start", selection: $start, displayedComponents: [.date, .hourAndMinute])
                }
                Section(header: Text("End Date & Time")) {
                    DatePicker("End", selection: $end, displayedComponents: [.date, .hourAndMinute])
                }
                Section(header: Text("Location")) {
                    TextField("Location", text: $location)
                }
                Section(header: Text("Note")) {
                    TextField("Note", text: $note)
                }
                Button("Save") {
                    viewModel.addTask(
                        title: title,
                        startDate: start,
                        endDate: end,
                        location: location,
                        note: note
                    )
                    pm.wrappedValue.dismiss()
                }
                .frame(maxWidth: .infinity, alignment: .center)
            }
            .navigationTitle("Add Task")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") { pm.wrappedValue.dismiss() }
                }
            }
        }
    }
}

// MARK: - TaskDetailView

struct TaskDetailView: View {
    @Environment(\.presentationMode) var pm
    @ObservedObject var viewModel: TaskViewModel
    @State var task: Task
    @State private var now = Date()
    @State private var progress: Double = 0
    @State private var isEditing = false
    private let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    var body: some View {
        Form {
            Section(header: Text("Progress")) {
                let prog: Double = {
                    switch task.state {
                    case .done:   return 1
                    case .atWork: return progress
                    case .notAtWork: return 0
                    }
                }()
                HStack { Spacer()
                    Image(task.state.assetName)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 200, height: 200)
                        .overlay(Circle().stroke(Color.primary, lineWidth: 2))
                        .mask(PieShape(progress: prog))
                        .animation(.linear, value: progress)
                    Spacer() }
            }
            Section(header: Text("Task")) {
                if isEditing {
                    TextField("Title", text: $task.title)
                } else {
                    Text(task.title)
                }
            }
            Section(header: Text("Start Date & Time")) {
                if isEditing {
                    DatePicker("Start", selection: Binding(
                        get: { task.startDate ?? Date() },
                        set: { task.startDate = $0 }
                    ), displayedComponents: [.date, .hourAndMinute])
                } else {
                    Text(task.startDate.map { DateFormatter.localizedString(from: $0, dateStyle: .medium, timeStyle: .short) } ?? "-")
                }
            }
            Section(header: Text("End Date & Time")) {
                if isEditing {
                    DatePicker("End", selection: Binding(
                        get: { task.endDate ?? Date() },
                        set: { task.endDate = $0 }
                    ), displayedComponents: [.date, .hourAndMinute])
                } else {
                    Text(task.endDate.map { DateFormatter.localizedString(from: $0, dateStyle: .medium, timeStyle: .short) } ?? "-")
                }
            }
            Section(header: Text("Location")) {
                if isEditing {
                    TextField("Location", text: Binding(
                        get: { task.location ?? "" },
                        set: { task.location = $0 }
                    ))
                } else {
                    Text(task.location ?? "-")
                }
            }
            Section(header: Text("Note")) {
                if isEditing {
                    TextField("Note", text: Binding(
                        get: { task.note ?? "" },
                        set: { task.note = $0 }
                    ))
                } else {
                    Text(task.note ?? "-")
                }
            }
            Section(header: Text("Status")) {
                if isEditing {
                    Picker("Status", selection: $task.state) {
                        ForEach(TaskState.allCases) { state in
                            Text(state.rawValue).tag(state)
                        }
                    }
                    .pickerStyle(SegmentedPickerStyle())
                } else {
                    Text(task.state.rawValue)
                }
            }
            if isEditing {
                Section {
                    Button("Save") {
                        viewModel.updateTask(task)
                        isEditing = false
                        pm.wrappedValue.dismiss()
                    }
                }
            }
            Section {
                Button(role: .destructive) {
                    viewModel.deleteTask(task)
                    pm.wrappedValue.dismiss()
                } label: {
                    Text("Delete Task")
                }
            }
        }
        .navigationTitle("Task Detail")
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                if !isEditing {
                    Button("Edit") { isEditing = true }
                }
            }
            if let end = task.endDate, now > end {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Image(systemName: "exclamationmark.circle.fill").foregroundColor(.red)
                }
            }
        }
        .onReceive(timer) { date in
            now = date
            if !isEditing {
                var t = task
                t.autoUpdateState(at: now)
                task = t
            }
            progress = task.progress(at: now)
        }
    }
}

// MARK: - Preview

struct ContentView_Previews: PreviewProvider {
    static var previews: some View { ContentView() }
}
