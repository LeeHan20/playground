//
//  MyToDoApp2Tests.swift
//  MyToDoApp2Tests
//
//  Created by 이한 on 5/3/25.
//

import Testing
@testable import MyToDoApp2

struct MyToDoApp2Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
